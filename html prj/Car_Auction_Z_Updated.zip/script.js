function submitBid() {
    const amount = document.getElementById('bidAmount').value;
    if (amount) {
        alert("Your bid of $" + amount + " has been submitted!");
    } else {
        alert("Please enter a valid amount.");
    }
}
